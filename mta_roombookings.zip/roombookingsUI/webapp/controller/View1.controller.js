sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/odata/v4/ODataModel"
], function (jQuery, Controller, ODataModel) {
	"use strict";

	return Controller.extend("roombookingsUI.roombookingsUI.controller.View1", {
		onInit: function () {
	
		//accessODatamodeldeclaredinmanifest.jsonfile
		var oModel=this.getOwnerComponent().getModel("ODataModel");
		//setthemodelonviewtobeusedbytheUIcontrols
		//jQuery.sap.log.info(oModel);
		this.getView().setModel(oModel);

		}
	});
});