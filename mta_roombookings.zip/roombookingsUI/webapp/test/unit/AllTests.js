sap.ui.define([
	"roombookingsUI/roombookingsUI/test/unit/controller/View1.controller"
], function () {
	"use strict";
});